package com.example.bove1;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

public class Char implements Serializable {
    int CPF;
    String nome;
    String email;
    int idade;
}
