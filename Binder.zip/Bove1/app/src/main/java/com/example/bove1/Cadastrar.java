package com.example.bove1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Cadastrar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar);
        final EditText cpfcampo = findViewById(R.id.cpfchar);
        final EditText nomecampo = findViewById(R.id.nomechar);
        final EditText emailcampo = findViewById(R.id.emailchar);
        final EditText idadecampo = findViewById(R.id.idadechar);
        Button cadastrarbutao = findViewById(R.id.cadastrar);

        cadastrarbutao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Char char1 = new Char();
                char1.CPF = Integer.parseInt(cpfcampo.getText().toString());
                char1.idade = Integer.parseInt(idadecampo.getText().toString());
                char1.nome = nomecampo.getText().toString();
                char1.email = emailcampo.getText().toString();
                SalvarChar(char1);
            }
        });
    }
    public void SalvarChar(Char char1){
        Intent intento = new Intent(this, MainActivity.class);
        intento.putExtra("Char", char1);
        startActivityForResult(intento,1);
    }
}
