package com.example.bove1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button cadastroButton = findViewById(R.id.cadastrobutton);
        Button listButton = findViewById(R.id.listbutton);

        cadastroButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Criaractivity(Cadastrar.class,true);
            }
        });

        listButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Criaractivity(Listar.class,false);
            }
        });
        Intent intent = getIntent();
        Char
    }
    public void Criaractivity(Class classe, boolean i){
        Intent intento = new Intent(this, classe);
        if(i){
            startActivity(intento);
        }else{
            intento.putExtra("Listadechar",ArrayList<Char>)
        }
    }


}
